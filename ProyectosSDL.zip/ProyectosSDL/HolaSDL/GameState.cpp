#include "GameState.h"
#include "Background.h"
#include "EventHandler.h"
#include "SDLApplication.h"
#include "GameObject.h"
#include "GameStateMachine.h"
#include "Arrow.h"

GameState::GameState(GameStateMachine* _gsm, SDLApplication* _app) :gsm(_gsm), app(_app) {}

GameState::~GameState() {

}

void GameState::update() {
	for (auto it = gameObjects.begin(); it != gameObjects.end(); ++it) {
		(*it)->update();
	}
}

void GameState::render() {
	background->render({ 0,0,background->getW(),background->getH() }, SDL_FLIP_NONE);
	for (auto it = gameObjects.begin(); it != gameObjects.end(); ++it) {
		(*it)->render();
	}
}

void GameState::handleEvents() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		if (event.type != SDL_QUIT) {
			for (auto eventIT = eventObjects.begin(); eventIT != eventObjects.end(); ++eventIT) {
				auto* aux = dynamic_cast<EventHandler*>(*eventIT);
				(aux)->handleEvent(event);
			}
		}
	}
}

//Elimina todos los objetos 
void GameState::deleteObjects() {
	if (!objectsToErase.empty()) {
		cout << objectsToErase.size() << " ";
		auto OTEIT = objectsToErase.begin();
		while (OTEIT != objectsToErase.end()) {
			auto GOIT = gameObjects.begin();
			bool found = false;
			while (!found && GOIT != gameObjects.end()) {
				if ((*OTEIT) == (*GOIT)) {//Coincidencia entre objectToErase y gameObject
					
					if (dynamic_cast<EventHandler*>(*OTEIT)) {
						bool eventFounded = false;
						auto EHIT = eventObjects.begin();
						while (!eventFounded && EHIT != eventObjects.end())
						{
							auto aux = dynamic_cast<GameObject*>(*EHIT);
							if (*OTEIT == aux) {
								
								eventObjects.erase(EHIT);
								eventFounded = true;
								found = true;
							}
							else EHIT++;
						}
					}
					else if (dynamic_cast<Arrow*>(*OTEIT)) {
						auto ARWIT = arrows.begin();
						bool arrowFounded = false;
						while (!arrowFounded && ARWIT != arrows.end())
						{
							if ((*OTEIT) == (*ARWIT)) {
								static_cast<Arrow*>(*ARWIT)->bonusStack();
								arrows.erase(ARWIT);
								arrowFounded = true;
								found = true;
							}
							else ARWIT++;
						}
					}
					auto auxIT = GOIT;
					auto auxEIT = OTEIT;
					GameObject* gm = *GOIT;
					OTEIT++;
					GOIT++;
					objectsToErase.erase(auxEIT);
					gameObjects.erase(auxIT);
					delete (gm);
					found = true;
				}
				else GOIT++;
			}
		}
		cout << objectsToErase.size() << endl;

	}
}

//Comprueba las collisiones entre las arrows y los gameObjects(Luego cambiar a preguntar si tiene un handleEvent)
/*void GameState::checkCollision() {
	for (auto arrowIT = arrows.begin(); arrowIT != arrows.end(); ++arrowIT) {
		for (auto gameObIT = gameObjects.begin(); gameObIT != gameObjects.end(); ++gameObIT) {
			auto* currGO = dynamic_cast<SDLGameObject*>(*gameObIT);
			SDL_Rect rc = (*arrowIT)->getRect();		//Esto no me funciona en el hasInterrsection
			if (currGO != nullptr && currGO->isCollisionable() && SDL_HasIntersection(&currGO->getRect(), &rc))
			{
				switch (currGO->getId())
				{
				case OBJECT_BALLON:
					(*arrowIT)->addStack();
					break;
				case OBJECT_BUTTERFLY:
					/*if (currPoints - POINTS_TO_SUB < 0) currPoints = 0;			//Nunca se obtiene una puntuaci�n negativa
					else currPoints -= POINTS_TO_SUB;
					currButterflies--;
					SCB->updatePoints(currPoints);
					break;
				case OBJECT_REWARD:


				default:
					break;
				}
				//nextLevel();
				currGO->startDestruction();
			}
		}
	}
}*/