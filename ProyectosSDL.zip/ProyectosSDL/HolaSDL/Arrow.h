#pragma once
#include "SDLGameObject.h"
#include "PlayState.h"


class Arrow: public SDLGameObject
{
private:
	int arrowLimit = 700;
	int stack = 0;
public:
	Arrow(Point2D _pos, Vector2D _dir, int _h, int _w, Texture* _texture, GameState* _owner, int _id, int _speed) 
		:SDLGameObject(_pos, _dir, _h, _w, _texture, _owner, _id,_speed) {};
	virtual void update();
	void addStack() { stack++; };
	void bonusStack() { static_cast<PlayState*>(ownerState)->stackArrows(stack); };
};

