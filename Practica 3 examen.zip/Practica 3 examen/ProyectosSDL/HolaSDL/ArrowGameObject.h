#pragma once
#include "SDLGameObject.h"

class ArrowGameObject : public SDLGameObject
{
};

